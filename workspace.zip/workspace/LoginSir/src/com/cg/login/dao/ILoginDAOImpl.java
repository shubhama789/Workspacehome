package com.cg.login.dao;

import java.sql.Connection;

import com.cg.login.bean.LoginBean;
import com.cg.login.exception.LoginException;
import com.cg.login.util.DbConnection;

public class ILoginDAOImpl implements ILoginDAO {

	@Override
	public boolean verifyLogin(LoginBean loginBean) throws LoginException, ClassNotFoundException {
		boolean result = true;
		//Connection connection = DbConnection.getConnection();
		
		return result;
	}

}
