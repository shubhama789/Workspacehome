package com.cg.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class InboxServlet
 */
@WebServlet("/InboxServlet")
public class InboxServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(false);
		if(session.getAttribute("username")!=null) {
			
			response.setContentType("text/html");
			PrintWriter pw = response.getWriter();
			
			pw.print("<html><body>"
					+"<h3>"
					+ "Wlcome to inbox"
					+ session.getAttribute("username")
					+"! <br/>"
					+ "<form action='SentItemsServlet' method='post'><input type='submit' value='Sent Items'></form>"
					+ "<br/>"
					+ "<form action='LogoutServlet' method='post'><input type='submit' value='Logout'></form>"
					+ "<a href = 'index.html'>go to loginpage </a>"
					+"</h3>"
					+"</body></html>");
			
		}else {
			
			response.setContentType("text/html");
			PrintWriter pw = response.getWriter();
			
			pw.print("<html><body>"
					+"<h3>"
					+ "stupid fello  login first!<br/>"
					+ "<a href = 'index.html'>go to loginpage </a>"
					+"</h3>"
					+"</body></html>");
		}
	}

}
