package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SecondServlet
 */
@WebServlet("/SecondServlet")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public SecondServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		HttpSession session = request.getSession();
		
		pw.println("This is second servlet page "
				+ "<html>"
				+ "<body>"
				+ "<br>"
				+ "<hr>"
				+ "Your Concatinated value is :"+request.getAttribute("concat")
				+ "</body>"
				+ "</html>");
		System.out.println("in doget");
		String dummy1 = (String)session.getAttribute("abc");
		String dummy2 = (String)session.getAttribute("def");
		pw.println("This is second servlet page "
				+ "<html>"
				+ "<body>"
				+ "<br>"
				+ "<hr>"
				+ "Your Concatinated value is :"+dummy1+dummy2
				+ "</body>"
				+ "</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

}
