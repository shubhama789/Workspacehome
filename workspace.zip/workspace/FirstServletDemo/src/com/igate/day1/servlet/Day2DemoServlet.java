package com.igate.day1.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Day2DemoServlet
 */
@WebServlet(
		description = "This is servlet version 3", 
		urlPatterns = { "/Day2DemoServlet" }, 
		initParams = { 
				@WebInitParam(name = "CityList", value = "bengaluru,chennai,mumbai,hydrebad")
		})
public class Day2DemoServlet extends HttpServlet 
{
	String values,values1;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Day2DemoServlet() 
    {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    public void init()
    {
    	values1=getServletContext().getInitParameter("CityList");
    	 values=getServletConfig().getInitParameter("CityList");
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		/*String startHtml="<html><head><title>City list</title></head>"+
		"<body>The cities are: ";
		String endHtml="</body></html>";
		out.println(startHtml+ " "+values+endHtml);*/
		out.println(values1);
		out.println(values);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

}
